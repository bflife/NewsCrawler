# -*- coding: utf-8 -*-
"""
新闻爬虫集合
包含所有平台的爬虫实现
"""

__version__ = "1.0.0"
__all__ = [
    "wechat_news",
    "toutiao_news",
    "detik_news",
    "lennysnewsletter",
    "naver_news",
    "quora"
]
