# -*- coding: utf-8 -*-
from .bbc_news import BBCNewsCrawler, RequestHeaders

__all__ = ['BBCNewsCrawler', 'RequestHeaders']
