from .detik_news import DetikNewsCrawler, RequestHeaders

__all__ = ["DetikNewsCrawler", "RequestHeaders"]