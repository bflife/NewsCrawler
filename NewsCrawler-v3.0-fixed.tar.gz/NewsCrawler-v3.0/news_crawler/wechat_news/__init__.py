# -*- coding: utf-8 -*-
from .wechat_news import RequestHeaders, WeChatNewsCrawler

__all__ = ["WeChatNewsCrawler", "RequestHeaders"]
    