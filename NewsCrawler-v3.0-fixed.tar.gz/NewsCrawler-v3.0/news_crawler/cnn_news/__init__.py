# -*- coding: utf-8 -*-
from .cnn_news import CNNNewsCrawler, RequestHeaders

__all__ = ['CNNNewsCrawler', 'RequestHeaders']
